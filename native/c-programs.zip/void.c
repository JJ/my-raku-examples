#include <stdio.h>

void this_is_void () {
    printf("This is void\n");
}
